from .main import create_app

EmcieServer = create_app
