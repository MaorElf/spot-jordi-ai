def skill(first_number: float, second_number: float) -> float:
    return first_number * second_number
