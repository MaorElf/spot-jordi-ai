from typing import List


def skill() -> List[str]:
    return ["olives", "onion", "anchobi", "cashew"]
